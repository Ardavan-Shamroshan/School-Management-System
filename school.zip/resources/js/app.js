import '../css/app.css';
import './bootstrap';

import.meta.glob([
    '../assets/images/**',
    '../assets/fonts/**',
    '../assets/files/**',
]);
